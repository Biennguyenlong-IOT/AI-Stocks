
import { GoogleGenAI, Type } from "@google/genai";
import { StockAnalysis, ScreenerResult, MarketOverview } from "./types";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

// Cấu hình thời gian Cache (milliseconds)
const CACHE_TIMES = {
  MARKET: 30 * 60 * 1000, // 30 phút
  STOCK: 60 * 60 * 1000,  // 1 giờ
};

/**
 * Hàm hỗ trợ Cache
 */
const getCache = (key: string) => {
  const cached = localStorage.getItem(`vntrade_cache_${key}`);
  if (!cached) return null;
  const { data, timestamp } = JSON.parse(cached);
  if (Date.now() - timestamp > (key === 'market' ? CACHE_TIMES.MARKET : CACHE_TIMES.STOCK)) {
    localStorage.removeItem(`vntrade_cache_${key}`);
    return null;
  }
  return data;
};

const setCache = (key: string, data: any) => {
  localStorage.setItem(`vntrade_cache_${key}`, JSON.stringify({
    data,
    timestamp: Date.now()
  }));
};

const getModelId = (): string => {
  const savedModel = localStorage.getItem('vntrade_custom_model');
  // Làm sạch các ID model sai có thể đã lưu trong localStorage (lỗi 404)
  const invalidModels = ['gemini-2.5-flash-latest', 'undefined', 'null'];
  if (!savedModel || invalidModels.includes(savedModel)) return 'gemini-3-flash-preview';
  return savedModel;
};

async function callWithRetry<T>(fn: () => Promise<T>, retries = 2, delay = 3000): Promise<T> {
  try {
    return await fn();
  } catch (error: any) {
    const errorStr = JSON.stringify(error);
    const isQuotaError = error?.status === 429 || errorStr.includes('429');
    const isNotFoundError = error?.status === 404 || errorStr.includes('404') || errorStr.includes('NOT_FOUND');

    if (isNotFoundError) {
      throw new Error("MODEL_NOT_FOUND: Model bạn chọn không khả dụng. Vui lòng vào Cài đặt và chọn 'Gemini 3 Flash'.");
    }

    if (retries > 0 && isQuotaError) {
      await new Promise(resolve => setTimeout(resolve, delay));
      return callWithRetry(fn, retries - 1, delay * 2);
    }
    throw error;
  }
}

export const getMarketOverview = async (forceRefresh = false): Promise<MarketOverview> => {
  if (!forceRefresh) {
    const cached = getCache('market');
    if (cached) return { ...cached, isCached: true };
  }

  return callWithRetry(async () => {
    const ai = getAI();
    const model = getModelId();
    const prompt = `Phân tích VN-Index, HNX, UPCoM hôm nay qua Google Search. Trả về JSON: indices (name, value, change, percent), sentiment (Hưng phấn/Tích cực/Trung lập/Tiêu cực/Hoảng loạn), summary (tóm tắt ngắn), topSectors (name, performance), foreignFlow, recommendation.`;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            indices: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { name: { type: Type.STRING }, value: { type: Type.STRING }, change: { type: Type.STRING }, percent: { type: Type.STRING } }, required: ['name', 'value', 'change', 'percent'] } },
            sentiment: { type: Type.STRING },
            summary: { type: Type.STRING },
            topSectors: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { name: { type: Type.STRING }, performance: { type: Type.STRING } }, required: ['name', 'performance'] } },
            foreignFlow: { type: Type.STRING },
            recommendation: { type: Type.STRING }
          },
          required: ['indices', 'sentiment', 'summary', 'topSectors', 'foreignFlow', 'recommendation']
        }
      }
    });

    const overview: MarketOverview = JSON.parse(response.text || '{}');
    overview.sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks
      ?.filter(c => c.web)
      ?.map(c => ({ title: c.web!.title || 'Nguồn', uri: c.web!.uri || '' })) || [];
    
    setCache('market', overview);
    return overview;
  });
};

export const analyzeStock = async (symbol: string, forceRefresh = false): Promise<StockAnalysis> => {
  const s = symbol.toUpperCase().trim();
  if (!forceRefresh) {
    const cached = getCache(`stock_${s}`);
    if (cached) return { ...cached, isCached: true };
  }

  return callWithRetry(async () => {
    const ai = getAI();
    const model = getModelId();
    const prompt = `Phân tích mã ${s} (Chứng khoán VN) qua Google Search. JSON: symbol, trend (Uptrend/Downtrend/Sideways), isBottom (bool), weeklyOutlook, monthlyOutlook, keyLevels (support, resistance, entry: number), reasoning.`;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            symbol: { type: Type.STRING },
            trend: { type: Type.STRING },
            isBottom: { type: Type.BOOLEAN },
            weeklyOutlook: { type: Type.STRING },
            monthlyOutlook: { type: Type.STRING },
            keyLevels: { type: Type.OBJECT, properties: { support: { type: Type.NUMBER }, resistance: { type: Type.NUMBER }, entry: { type: Type.NUMBER } }, required: ['support', 'resistance', 'entry'] },
            reasoning: { type: Type.STRING }
          },
          required: ['symbol', 'trend', 'isBottom', 'weeklyOutlook', 'monthlyOutlook', 'keyLevels', 'reasoning']
        }
      }
    });

    const analysis: StockAnalysis = JSON.parse(response.text || '{}');
    analysis.sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks
      ?.filter(c => c.web)
      ?.map(c => ({ title: c.web!.title || 'Nguồn', uri: c.web!.uri || '' })) || [];
    
    setCache(`stock_${s}`, analysis);
    return analysis;
  });
};

export const screenStocks = async (criteria: { trend: string; bottom: boolean; priceRange: string }): Promise<ScreenerResult[]> => {
  return callWithRetry(async () => {
    const ai = getAI();
    const model = getModelId();
    const prompt = `Top 5 mã chứng khoán VN: Xu hướng ${criteria.trend}, ${criteria.bottom ? 'đang tạo đáy' : 'bất kỳ'}, giá ${criteria.priceRange}. JSON Array: symbol, price, change, reason, tags (array).`;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              symbol: { type: Type.STRING },
              price: { type: Type.STRING },
              change: { type: Type.STRING },
              reason: { type: Type.STRING },
              tags: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ['symbol', 'price', 'change', 'reason', 'tags']
          }
        }
      }
    });

    return JSON.parse(response.text || '[]');
  });
};
