
import React, { useState } from 'react';
import { analyzeStock } from '../geminiService';
import { StockAnalysis } from '../types';
import { TrendingUp, TrendingDown, Target, Shield, Zap, Search, Loader2, ExternalLink, Clock } from 'lucide-react';

export const AnalysisPanel: React.FC = () => {
  const [symbol, setSymbol] = useState('');
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<StockAnalysis | null>(null);
  const [error, setError] = useState('');

  const handleAnalyze = async (force = false) => {
    if (!symbol) return;
    setLoading(true);
    setError('');
    try {
      const res = await analyzeStock(symbol, force);
      setData(res);
    } catch (err: any) {
      if (err?.message?.includes('429')) {
        setError('Hạn mức API Gemini hiện tại đã hết. Vui lòng đợi 1-2 phút và thử lại.');
      } else {
        setError('Không thể phân tích mã này. Vui lòng kiểm tra kết nối.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Mã cổ phiếu (VD: FPT, SSI, HPG...)"
            value={symbol}
            onChange={(e) => setSymbol(e.target.value.toUpperCase())}
            onKeyDown={(e) => e.key === 'Enter' && handleAnalyze(false)}
            className="w-full bg-slate-800 border border-slate-700 rounded-xl py-3 pl-11 pr-4 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
          />
        </div>
        <button
          onClick={() => handleAnalyze(false)}
          disabled={loading}
          className="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 px-6 rounded-xl font-semibold flex items-center gap-2 transition-colors"
        >
          {loading ? <Loader2 className="animate-spin w-5 h-5" /> : 'Phân Tích'}
        </button>
      </div>

      {error && (
        <div className="p-4 bg-rose-900/30 border border-rose-500/50 rounded-xl text-rose-200 text-sm">
          {error}
        </div>
      )}

      {data && (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
          <div className="flex justify-end">
            {data.isCached && (
              <button 
                onClick={() => handleAnalyze(true)}
                className="flex items-center gap-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest hover:text-blue-400 transition-colors"
              >
                <Clock size={12} /> Dữ liệu đã lưu - Làm mới ngay?
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2 space-y-6">
              <div className="glass p-6 rounded-2xl">
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <h2 className="text-3xl font-black">{data.symbol}</h2>
                    <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mt-1">AI Stock Insights</p>
                  </div>
                  <div className={`px-4 py-2 rounded-full flex items-center gap-2 font-bold ${
                    data.trend === 'Uptrend' ? 'bg-emerald-500/20 text-emerald-400' : 
                    data.trend === 'Downtrend' ? 'bg-rose-500/20 text-rose-400' : 'bg-amber-500/20 text-amber-400'
                  }`}>
                    {data.trend === 'Uptrend' ? <TrendingUp size={18} /> : <TrendingDown size={18} />}
                    {data.trend}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                  <div className="bg-slate-900/50 p-4 rounded-xl border border-white/5">
                    <span className="text-[10px] text-slate-500 block mb-2 font-bold uppercase tracking-widest">Triển vọng Tuần</span>
                    <p className="text-slate-200 text-sm leading-relaxed italic">"{data.weeklyOutlook}"</p>
                  </div>
                  <div className="bg-slate-900/50 p-4 rounded-xl border border-white/5">
                    <span className="text-[10px] text-slate-500 block mb-2 font-bold uppercase tracking-widest">Triển vọng Tháng</span>
                    <p className="text-slate-200 text-sm leading-relaxed italic">"{data.monthlyOutlook}"</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="font-bold flex items-center gap-2 text-blue-400 uppercase text-xs tracking-widest">
                    <Zap className="text-yellow-400" size={16} /> Nhận định phân tích
                  </h3>
                  <p className="text-slate-300 leading-relaxed font-medium">{data.reasoning}</p>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="glass p-6 rounded-2xl border-l-4 border-l-blue-500 shadow-xl">
                <h3 className="font-black text-sm uppercase tracking-widest mb-6 flex items-center gap-2">
                  <Target size={18} className="text-blue-400" /> Ngưỡng giá
                </h3>
                <div className="space-y-4">
                  {[
                    { label: 'Giá mua', val: data.keyLevels.entry, color: 'text-blue-400' },
                    { label: 'Kháng cự', val: data.keyLevels.resistance, color: 'text-rose-400' },
                    { label: 'Hỗ trợ', val: data.keyLevels.support, color: 'text-emerald-400' },
                  ].map((lvl, i) => (
                    <div key={i} className="flex justify-between items-center p-3 bg-slate-900/50 rounded-xl border border-white/5">
                      <span className="text-slate-500 text-xs font-bold uppercase">{lvl.label}</span>
                      <span className={`text-xl font-black ${lvl.color}`}>{lvl.val.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className={`p-6 rounded-2xl border ${data.isBottom ? 'bg-emerald-500/10 border-emerald-500/30' : 'bg-slate-800/30 border-white/5'}`}>
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-xl ${data.isBottom ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-700 text-slate-400'}`}>
                    <Shield size={24} />
                  </div>
                  <div>
                    <h4 className="font-black text-sm uppercase">{data.isBottom ? 'Vùng đáy' : 'Chưa xác định đáy'}</h4>
                    <p className="text-[10px] text-slate-500 font-bold uppercase mt-1 tracking-tighter">
                      {data.isBottom ? 'Tín hiệu mua an toàn' : 'Cần quan sát thêm'}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
