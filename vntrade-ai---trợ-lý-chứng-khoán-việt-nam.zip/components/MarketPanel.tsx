
import React, { useEffect, useState } from 'react';
import { getMarketOverview } from '../geminiService';
import { MarketOverview } from '../types';
import { LayoutDashboard, TrendingUp, Users, Info, RefreshCw, ExternalLink, Globe, PieChart, Activity, Clock, AlertCircle } from 'lucide-react';

export const MarketPanel: React.FC = () => {
  const [data, setData] = useState<MarketOverview | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchMarketData = async (force = false) => {
    setLoading(true);
    setError(null);
    try {
      const result = await getMarketOverview(force);
      setData(result);
    } catch (err: any) {
      console.error("Lỗi lấy dữ liệu thị trường:", err);
      setError(err.message || "Không thể lấy dữ liệu thị trường. Vui lòng thử lại sau.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMarketData();
  }, []);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] gap-4">
        <RefreshCw className="animate-spin text-blue-500 w-10 h-10" />
        <p className="text-slate-400 animate-pulse font-medium uppercase tracking-widest text-[10px]">Đang quét dữ liệu VN-Index...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] gap-6 text-center max-w-lg mx-auto">
        <div className="p-4 bg-rose-500/20 text-rose-400 rounded-full">
          <AlertCircle size={40} />
        </div>
        <div className="space-y-2">
          <h3 className="text-xl font-bold text-white">Lỗi kết nối AI</h3>
          <p className="text-slate-400 text-sm leading-relaxed">{error}</p>
        </div>
        <button 
          onClick={() => fetchMarketData(true)}
          className="bg-blue-600 hover:bg-blue-500 text-white px-8 py-3 rounded-2xl font-bold shadow-lg shadow-blue-900/20 transition-all active:scale-95 flex items-center gap-2"
        >
          <RefreshCw size={18} /> Thử lại ngay
        </button>
      </div>
    );
  }

  if (!data) return null;

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      {/* Caching Status Bar */}
      <div className="flex justify-end px-2">
        {data.isCached ? (
          <div className="flex items-center gap-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest bg-slate-900/50 px-3 py-1.5 rounded-full border border-white/5">
            <Clock size={12} /> Dữ liệu đã lưu (Cache)
            <button onClick={() => fetchMarketData(true)} className="ml-2 text-blue-400 hover:text-blue-300 underline">Làm mới</button>
          </div>
        ) : (
          <div className="flex items-center gap-2 text-[10px] font-bold text-emerald-500 uppercase tracking-widest bg-emerald-500/10 px-3 py-1.5 rounded-full border border-emerald-500/20">
            <Activity size={12} /> Dữ liệu Live từ AI
          </div>
        )}
      </div>

      <div className="glass rounded-3xl overflow-hidden border-white/5 shadow-2xl">
        <div className="bg-slate-800/50 p-6 border-b border-white/5 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-600/20 rounded-xl">
              <Activity className="text-blue-400" size={20} />
            </div>
            <h3 className="font-bold text-lg uppercase tracking-tight">Chỉ số chính</h3>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-900/30 text-slate-500 text-[10px] uppercase font-bold tracking-widest">
                <th className="px-6 py-4">Chỉ số</th>
                <th className="px-6 py-4">Giá trị</th>
                <th className="px-6 py-4">Thay đổi</th>
                <th className="px-6 py-4">%</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {data.indices.map((idx, i) => {
                const isPos = !idx.change.startsWith('-');
                return (
                  <tr key={i} className="hover:bg-white/5 transition-colors">
                    <td className="px-6 py-5 font-black text-slate-200">{idx.name}</td>
                    <td className="px-6 py-5 font-mono text-lg">{idx.value}</td>
                    <td className={`px-6 py-5 font-bold ${isPos ? 'text-emerald-400' : 'text-rose-400'}`}>{idx.change}</td>
                    <td className={`px-6 py-5 font-bold ${isPos ? 'text-emerald-400' : 'text-rose-400'}`}>
                      <span className={`px-2 py-1 rounded-lg ${isPos ? 'bg-emerald-500/10' : 'bg-rose-500/10'}`}>{idx.percent}</span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass p-6 rounded-3xl border-l-4 border-l-amber-500">
          <h3 className="text-slate-400 text-xs font-bold uppercase tracking-wider mb-2">Tâm Lý</h3>
          <p className="text-2xl font-black text-amber-400">{data.sentiment}</p>
        </div>
        <div className="glass p-6 rounded-3xl border-l-4 border-l-indigo-500 md:col-span-2">
          <h3 className="text-slate-400 text-xs font-bold uppercase tracking-wider mb-2">Khối Ngoại</h3>
          <p className="text-xl font-bold text-slate-200">{data.foreignFlow}</p>
        </div>
      </div>

      <div className="glass p-8 rounded-3xl">
        <h3 className="text-xl font-bold flex items-center gap-3 mb-6 text-blue-400">
          <Activity size={24} /> Phân Tích & Khuyến Nghị
        </h3>
        <p className="text-slate-300 leading-relaxed italic mb-8">{data.summary}</p>
        <div className="p-4 bg-blue-600/10 border border-blue-500/20 rounded-2xl">
          <p className="text-slate-200 font-bold">"{data.recommendation}"</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="glass p-6 rounded-3xl">
          <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Nhóm Ngành</h3>
          <div className="space-y-3">
            {data.topSectors.map((sector, i) => (
              <div key={i} className="flex justify-between items-center p-3 bg-slate-900/40 rounded-xl">
                <span className="font-bold">{sector.name}</span>
                <span className={sector.performance.includes('+') ? 'text-emerald-400' : 'text-rose-400'}>{sector.performance}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="glass p-6 rounded-3xl">
          <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Nguồn Tin</h3>
          <div className="flex flex-wrap gap-2">
            {data.sources.map((src, i) => (
              <a key={i} href={src.uri} target="_blank" className="text-[10px] bg-slate-800 px-3 py-1.5 rounded-lg border border-white/5 text-blue-400 flex items-center gap-1">
                {src.title} <ExternalLink size={10} />
              </a>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
