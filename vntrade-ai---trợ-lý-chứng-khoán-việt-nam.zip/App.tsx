
import React, { useState, useEffect } from 'react';
import { AppTab, AppDataCloud } from './types';
import { MarketPanel } from './components/MarketPanel';
import { AnalysisPanel } from './components/AnalysisPanel';
import { ScreenerPanel } from './components/ScreenerPanel';
import { StrategyPanel } from './components/StrategyPanel';
import { PortfolioPanel } from './components/PortfolioPanel';
import { loadFromCloud, saveToCloud } from './syncService';
import { 
  BarChart3, Search, Lightbulb, LineChart, LayoutDashboard, Briefcase, 
  Settings, X, Cpu, HelpCircle, Database, Cloud, CloudOff, RefreshCw, CheckCircle2, Copy, Trash2, Merge
} from 'lucide-react';

// Cập nhật các ID model chính xác theo tài liệu Gemini API
const AI_MODELS = [
  { id: 'gemini-3-flash-preview', name: 'Gemini 3 Flash (Khuyên dùng)', description: 'Tốc độ cực nhanh, hỗ trợ tìm kiếm Google tốt nhất.' },
  { id: 'gemini-3-pro-preview', name: 'Gemini 3 Pro', description: 'Phân tích đa chiều, lập luận sâu sắc.' },
  { id: 'gemini-flash-latest', name: 'Gemini Flash Latest', description: 'Phiên bản ổn định, hạn mức cao.' }
];

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<AppTab>(AppTab.MARKET);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [showReadme, setShowReadme] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [copied, setCopied] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  
  const [syncUrl, setSyncUrl] = useState(localStorage.getItem('vntrade_sync_url') || '');
  const [selectedModel, setSelectedModel] = useState(localStorage.getItem('vntrade_custom_model_id') || 'gemini-3-flash-preview');
  const [customModelInput, setCustomModelInput] = useState(localStorage.getItem('vntrade_custom_model') || '');

  const [cloudData, setCloudData] = useState<AppDataCloud>(() => {
    const saved = localStorage.getItem('vntrade_local_state');
    return saved ? JSON.parse(saved) : {
      symbols: [],
      analyses: {},
      settings: { modelId: 'gemini-3-flash-preview', customModel: '' }
    };
  });

  useEffect(() => {
    localStorage.setItem('vntrade_local_state', JSON.stringify(cloudData));
  }, [cloudData]);

  useEffect(() => {
    if (syncUrl) {
      handleInitialLoad();
    }
  }, []);

  const handleInitialLoad = async () => {
    setIsSyncing(true);
    const remoteData = await loadFromCloud();
    if (remoteData) {
      setCloudData(prev => {
        const mergedSymbols = Array.from(new Set([...prev.symbols, ...(remoteData.symbols || [])]));
        const mergedAnalyses = { ...prev.analyses, ...(remoteData.analyses || {}) };
        
        return {
          ...prev,
          symbols: mergedSymbols,
          analyses: mergedAnalyses,
          settings: remoteData.settings || prev.settings
        };
      });
    }
    setIsSyncing(false);
  };

  const saveSettings = async () => {
    setIsSyncing(true);
    const cleanUrl = syncUrl.trim();
    
    localStorage.setItem('vntrade_sync_url', cleanUrl);
    localStorage.setItem('vntrade_custom_model_id', selectedModel);
    
    const finalModel = selectedModel === 'custom' ? customModelInput : selectedModel;
    localStorage.setItem('vntrade_custom_model', finalModel);

    const newData: AppDataCloud = {
      ...cloudData,
      settings: { modelId: selectedModel, customModel: finalModel }
    };

    if (cleanUrl) {
      await saveToCloud(newData);
    }
    
    setCloudData(newData);
    setIsSyncing(false);
    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
      setIsSettingsOpen(false);
    }, 1200);
  };

  const clearUrl = () => {
    if (window.confirm("Bạn có chắc muốn xóa URL đồng bộ hiện tại?")) {
      setSyncUrl('');
      localStorage.removeItem('vntrade_sync_url');
    }
  };

  const copyCodeV9 = () => {
    const code = `/** 
 * VNTrade AI Cloud Sync V9 - BẢO VỆ DỮ LIỆU
 * 1. Sheet _SYSTEM_STORAGE_: Lưu trữ thô
 * 2. Sheet DANH_MUC_DAU_TU: Hiển thị tách dòng
 */
function doPost(e) {
  try {
    var raw = e.postData.contents;
    var data = JSON.parse(raw);
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    
    var sysSheet = ss.getSheetByName("_SYSTEM_STORAGE_") || ss.insertSheet("_SYSTEM_STORAGE_");
    sysSheet.clear().getRange(1, 1).setValue(raw);
    sysSheet.hideSheet();

    var viewSheet = ss.getSheetByName("DANH_MUC_DAU_TU") || ss.insertSheet("DANH_MUC_DAU_TU", 0);
    viewSheet.clear();
    
    var h = [["MÃ CP", "XU HƯỚNG", "TÍN HIỆU", "GIÁ MUA", "HỖ TRỢ", "KHÁNG CỰ", "CẬP NHẬT"]];
    viewSheet.getRange(1, 1, 1, 7).setValues(h).setFontWeight("bold").setBackground("#1e40af").setFontColor("#ffffff").setHorizontalAlignment("center");

    var analyses = data.analyses || {};
    var symbols = data.symbols || [];
    var rows = [];
    for (var i = 0; i < symbols.length; i++) {
      var s = symbols[i];
      var a = analyses[s] || {};
      var k = a.keyLevels || { entry: 0, support: 0, resistance: 0 };
      rows.push([s, (a.trend || "Chờ xử lý"), (a.isBottom ? "✅ TẠO ĐÁY" : "🔍 THEO DÕI"), (k.entry || 0), (k.support || 0), (k.resistance || 0), (a.lastUpdated || "N/A")]);
    }
    
    if (rows.length > 0) {
      var r = viewSheet.getRange(2, 1, rows.length, 7);
      r.setValues(rows).setHorizontalAlignment("center");
      viewSheet.getRange(2, 4, rows.length, 3).setNumberFormat("#,##0");
      viewSheet.getRange(1, 1, rows.length + 1, 7).setBorder(true, true, true, true, true, true, "#e2e8f0", SpreadsheetApp.BorderStyle.SOLID);
    }
    viewSheet.setFrozenRows(1);
    viewSheet.autoResizeColumns(1, 7);
    return ContentService.createTextOutput("Sync V9 OK");
  } catch (err) {
    return ContentService.createTextOutput("Error: " + err.toString());
  }
}

function doGet() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName("_SYSTEM_STORAGE_");
  var data = sheet ? sheet.getRange(1, 1).getValue() : "{}";
  return ContentService.createTextOutput(data).setMimeType(ContentService.MimeType.JSON);
}`;
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen pb-20 relative">
      <nav className="sticky top-0 z-50 glass border-b border-white/5 px-4 lg:px-8 py-4 mb-8">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-6 group">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-tr from-blue-600 to-indigo-500 p-2.5 rounded-xl shadow-lg">
                <BarChart3 className="text-white w-6 h-6" />
              </div>
              <div>
                <h1 className="text-xl font-black text-white uppercase tracking-tighter italic">VNTrade <span className="text-blue-500">Cloud AI</span></h1>
                <div className="flex items-center gap-2">
                  <span className="text-[9px] text-slate-400 font-bold uppercase tracking-widest">Version 9 - Merge Logic</span>
                  {syncUrl ? <Cloud className="text-emerald-400 w-3 h-3" /> : <CloudOff className="text-rose-400 w-3 h-3" />}
                  {isSyncing && <RefreshCw size={10} className="animate-spin text-blue-400" />}
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="flex bg-slate-900/80 p-1 rounded-2xl border border-slate-700/50 backdrop-blur-md">
              {[
                { id: AppTab.MARKET, icon: LayoutDashboard, label: 'Thị Trường' },
                { id: AppTab.PORTFOLIO, icon: Briefcase, label: 'Danh Mục' },
                { id: AppTab.ANALYSIS, icon: LineChart, label: 'Phân Tích' },
                { id: AppTab.SCREENER, icon: Search, label: 'Tìm Mã' },
                { id: AppTab.STRATEGY, icon: Lightbulb, label: 'Chiến Lược' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-5 py-2 rounded-xl text-sm font-semibold transition-all ${
                    activeTab === tab.id ? 'bg-blue-600 text-white shadow-xl scale-105' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <tab.icon size={16} />
                  <span className="hidden md:inline">{tab.label}</span>
                </button>
              ))}
            </div>
            
            <button 
              onClick={() => setIsSettingsOpen(true)}
              className="p-3 bg-slate-800 hover:bg-slate-700 rounded-xl text-slate-400 border border-white/5 relative group transition-all active:scale-90"
            >
              <Settings size={20} className="group-hover:rotate-180 transition-transform duration-700" />
              {isSyncing && <RefreshCw className="absolute -top-1 -right-1 w-4 h-4 text-blue-400 animate-spin bg-slate-900 rounded-full" />}
            </button>
          </div>
        </div>
      </nav>

      {isSettingsOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-950/90 backdrop-blur-md p-4 animate-in fade-in duration-300">
          <div className="glass w-full max-w-5xl p-0 rounded-[3rem] shadow-2xl relative flex flex-col max-h-[90vh] overflow-hidden border border-white/10">
            <div className="p-8 border-b border-white/5 flex justify-between items-center bg-slate-900/50">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-indigo-500/10 rounded-2xl text-indigo-400">
                  <Merge size={24} />
                </div>
                <div>
                  <h2 className="text-xl font-black uppercase tracking-tight">Cấu hình Gộp Dữ Liệu V9</h2>
                  <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Không xoá dữ liệu cũ khi đồng bộ</p>
                </div>
              </div>
              <button onClick={() => setIsSettingsOpen(false)} className="p-2 text-slate-500 hover:text-white bg-slate-800 rounded-full transition-colors"><X size={20} /></button>
            </div>
            
            <div className="flex flex-1 overflow-hidden">
              <div className="w-64 bg-slate-900/30 border-r border-white/5 p-6 flex flex-col gap-3">
                <button onClick={() => setShowReadme(false)} className={`flex items-center gap-3 px-6 py-4 rounded-2xl text-sm font-bold transition-all ${!showReadme ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500 hover:bg-white/5'}`}>
                  <Database size={18} /> Kết nối URL
                </button>
                <button onClick={() => setShowReadme(true)} className={`flex items-center gap-3 px-6 py-4 rounded-2xl text-sm font-bold transition-all ${showReadme ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500 hover:bg-white/5'}`}>
                  <HelpCircle size={18} /> Hướng dẫn V9
                </button>
                <div className="mt-auto pt-6 border-t border-white/5">
                   <button onClick={clearUrl} className="flex items-center gap-3 px-6 py-4 rounded-2xl text-sm font-bold text-rose-400 hover:bg-rose-500/10 transition-all w-full">
                    <Trash2 size={18} /> Xóa URL cấu hình
                  </button>
                </div>
              </div>

              <div className="flex-1 p-10 overflow-y-auto bg-slate-900/20">
                {!showReadme ? (
                  <div className="space-y-10 animate-in slide-in-from-right-8 duration-500">
                    <div className="space-y-4">
                      <label className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
                        <Database size={14} className="text-indigo-500" /> URL Script (Ghi nhớ vĩnh viễn)
                      </label>
                      <input 
                        type="text"
                        value={syncUrl}
                        onChange={(e) => setSyncUrl(e.target.value)}
                        placeholder="Dán URL script.google.com..."
                        className="w-full bg-slate-950 border-2 border-slate-800 rounded-3xl px-6 py-5 outline-none focus:border-indigo-500 font-mono text-sm text-indigo-400 shadow-inner transition-all"
                      />
                      <div className="flex items-center gap-3 p-4 bg-indigo-500/5 rounded-2xl border border-indigo-500/10 italic">
                        <CheckCircle2 size={16} className="text-indigo-400" />
                        <p className="text-[11px] text-slate-400">Ứng dụng sẽ gộp (Merge) dữ liệu từ Sheet vào danh sách hiện tại của bạn.</p>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <label className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
                        <Cpu size={14} className="text-indigo-500" /> Model Phân Tích
                      </label>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {AI_MODELS.map(m => (
                          <button
                            key={m.id}
                            onClick={() => setSelectedModel(m.id)}
                            className={`text-left p-6 rounded-[2rem] border-2 transition-all group ${selectedModel === m.id ? 'bg-indigo-600/10 border-indigo-500 shadow-xl' : 'bg-slate-900 border-transparent hover:border-slate-700'}`}
                          >
                            <div className="font-black text-sm text-white mb-2 group-hover:text-indigo-400 transition-colors">{m.name}</div>
                            <div className="text-[10px] text-slate-500 leading-relaxed font-medium uppercase tracking-tighter">{m.description}</div>
                          </button>
                        ))}
                      </div>
                    </div>

                    <button 
                      onClick={saveSettings}
                      disabled={saveSuccess}
                      className={`w-full py-6 rounded-[2.5rem] font-black text-base transition-all shadow-2xl flex items-center justify-center gap-3 active:scale-95 ${
                        saveSuccess ? 'bg-emerald-600 text-white' : 'bg-gradient-to-r from-indigo-600 to-blue-600 hover:shadow-indigo-500/20'
                      }`}
                    >
                      {saveSuccess ? <CheckCircle2 size={24} /> : <Cloud size={24} />}
                      {saveSuccess ? 'CẤU HÌNH ĐÃ LƯU!' : 'LƯU & ĐỒNG BỘ GỘP'}
                    </button>
                  </div>
                ) : (
                  <div className="space-y-8 text-sm text-slate-400 max-w-3xl mx-auto pb-10">
                    <h3 className="text-white text-2xl font-black flex items-center gap-3 underline decoration-indigo-500 decoration-4 underline-offset-8">Cách thức Gộp Dữ Liệu V9</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="p-8 bg-slate-900/80 rounded-[2.5rem] border border-white/5 space-y-4">
                        <h4 className="text-emerald-400 font-black uppercase text-xs tracking-widest">An toàn dữ liệu</h4>
                        <p className="text-[12px] leading-relaxed">Khi bạn tải lại trang, App ưu tiên dùng dữ liệu trong bộ nhớ trình duyệt trước. Sau đó mới tìm kiếm thêm mã mới từ Sheet để gộp vào.</p>
                      </div>
                      <div className="p-8 bg-slate-900/80 rounded-[2.5rem] border border-white/5 space-y-4">
                        <h4 className="text-indigo-400 font-black uppercase text-xs tracking-widest">Đồng bộ 2 chiều</h4>
                        <p className="text-[12px] leading-relaxed">Mọi mã bạn thêm trên App hoặc thêm trực tiếp vào Sheet đều sẽ được đồng nhất qua cơ chế Merge Logic.</p>
                      </div>
                    </div>

                    <div className="p-8 bg-indigo-500/5 border border-indigo-500/20 rounded-[2.5rem] relative">
                      <div className="absolute -top-3 -right-3 bg-indigo-600 text-white text-[10px] px-3 py-1 rounded-full font-black uppercase">Mới</div>
                      <h4 className="text-white font-black mb-4 flex items-center gap-2 uppercase text-xs">Cập nhật mã Script V9:</h4>
                      <ol className="space-y-4 text-slate-300">
                        <li className="flex gap-4"><span className="bg-indigo-600 w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black shrink-0">1</span> Copy mã V9 ổn định bên dưới.</li>
                        <li className="flex gap-4"><span className="bg-indigo-600 w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black shrink-0">2</span> Mở Apps Script, xoá sạch mã V8 cũ.</li>
                        <li className="flex gap-4"><span className="bg-indigo-600 w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black shrink-0">3</span> Dán mã mới & Lưu lại.</li>
                        <li className="flex gap-4"><span className="bg-indigo-600 w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black shrink-0">4</span> Deploy &gt; New Deployment để lấy URL Web App mới.</li>
                      </ol>
                    </div>
                    
                    <div className="p-8 bg-slate-950 rounded-[2.5rem] border border-white/5 relative group shadow-inner">
                      <button 
                        onClick={copyCodeV9}
                        className="absolute right-8 top-8 flex items-center gap-2 px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 rounded-2xl text-white text-[11px] font-black transition-all shadow-xl active:scale-95 uppercase tracking-widest"
                      >
                        {copied ? <CheckCircle2 size={14} /> : <Copy size={14} />}
                        {copied ? 'ĐÃ COPY MÃ V9' : 'COPY MÃ V9 MỚI NHẤT'}
                      </button>
                      <pre className="bg-transparent p-2 rounded-xl text-[10px] font-mono overflow-x-auto text-indigo-400/90 max-h-[350px] scrollbar-thin">
{`/** VNTrade AI Cloud Sync V9 - MERGE LOGIC **/
function doPost(e) {
  try {
    var raw = e.postData.contents;
    var data = JSON.parse(raw);
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    
    var sysSheet = ss.getSheetByName("_SYSTEM_STORAGE_") || ss.insertSheet("_SYSTEM_STORAGE_");
    sysSheet.clear().getRange(1, 1).setValue(raw);
    sysSheet.hideSheet();

    var viewSheet = ss.getSheetByName("DANH_MUC_DAU_TU") || ss.insertSheet("DANH_MUC_DAU_TU", 0);
    viewSheet.clear();
    
    var h = [["MÃ CP", "XU HƯỚNG", "TÍN HIỆU", "GIÁ MUA", "HỖ TRỢ", "KHÁNG CỰ", "CẬP NHẬT"]];
    viewSheet.getRange(1, 1, 1, 7).setValues(h).setFontWeight("bold").setBackground("#1e40af").setFontColor("#ffffff").setHorizontalAlignment("center");

    var analyses = data.analyses || {};
    var symbols = data.symbols || [];
    var rows = [];
    for (var i = 0; i < symbols.length; i++) {
      var s = symbols[i];
      var a = analyses[s] || {};
      var k = a.keyLevels || { entry: 0, support: 0, resistance: 0 };
      rows.push([s, (a.trend || "N/A"), (a.isBottom ? "✅ ĐÁY" : "🔍 THEO DÕI"), (k.entry || 0), (k.support || 0), (k.resistance || 0), (a.lastUpdated || "")]);
    }
    
    if (rows.length > 0) {
      var r = viewSheet.getRange(2, 1, rows.length, 7);
      r.setValues(rows).setHorizontalAlignment("center");
      viewSheet.getRange(2, 4, rows.length, 3).setNumberFormat("#,##0");
      viewSheet.getRange(1, 1, rows.length + 1, 7).setBorder(true, true, true, true, true, true, "#e2e8f0", SpreadsheetApp.BorderStyle.SOLID);
    }
    viewSheet.setFrozenRows(1);
    viewSheet.autoResizeColumns(1, 7);
    return ContentService.createTextOutput("OK V9");
  } catch (err) {
    return ContentService.createTextOutput("Error: " + err.toString());
  }
}

function doGet() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName("_SYSTEM_STORAGE_");
  var data = sheet ? sheet.getRange(1, 1).getValue() : "{}";
  return ContentService.createTextOutput(data).setMimeType(ContentService.MimeType.JSON);
}`}
                      </pre>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      <main className="max-w-7xl mx-auto px-4 lg:px-8">
        <div className="min-h-[600px]">
          {activeTab === AppTab.MARKET && <MarketPanel />}
          {activeTab === AppTab.PORTFOLIO && <PortfolioPanel cloudData={cloudData} setCloudData={setCloudData} />}
          {activeTab === AppTab.ANALYSIS && <AnalysisPanel />}
          {activeTab === AppTab.SCREENER && <ScreenerPanel />}
          {activeTab === AppTab.STRATEGY && <StrategyPanel />}
        </div>
      </main>
    </div>
  );
};

export default App;
