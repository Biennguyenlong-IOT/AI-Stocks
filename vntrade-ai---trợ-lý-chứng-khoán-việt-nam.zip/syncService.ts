
import { AppDataCloud } from "./types";

/**
 * Lấy URL Webhook từ localStorage
 */
const getSyncUrl = () => localStorage.getItem('vntrade_sync_url') || '';

/**
 * Lưu dữ liệu lên Google Sheets.
 */
export const saveToCloud = async (data: AppDataCloud): Promise<boolean> => {
  const url = getSyncUrl();
  if (!url) return false;

  try {
    // Sử dụng text/plain để tránh các vấn đề CORS phức tạp với Apps Script
    await fetch(url, {
      method: 'POST',
      body: JSON.stringify(data),
      mode: 'no-cors',
      headers: {
        'Content-Type': 'text/plain'
      }
    });
    return true;
  } catch (error) {
    console.error("Lỗi khi đồng bộ lên Google Sheets:", error);
    return false;
  }
};

/**
 * Tải dữ liệu từ Google Sheets.
 * Apps Script doGet V8 sẽ trả về dữ liệu thô từ sheet "_SYSTEM_STORAGE_".
 */
export const loadFromCloud = async (): Promise<AppDataCloud | null> => {
  const url = getSyncUrl();
  if (!url) return null;

  try {
    const response = await fetch(url);
    if (!response.ok) return null;
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Lỗi khi tải từ Google Sheets:", error);
    return null;
  }
};
