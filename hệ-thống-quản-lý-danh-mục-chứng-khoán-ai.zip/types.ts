
export interface StockHolding {
  id: string;
  symbol: string;
  name: string;
  quantity: number;
  avgPrice: number;
  currentPrice: number;
  sector: string;
}

export type TransactionType = 'BUY' | 'SELL' | 'DEPOSIT' | 'WITHDRAW' | 'DIVIDEND_CASH' | 'DIVIDEND_STOCK';

export interface Transaction {
  id: string;
  date: string;
  type: TransactionType;
  symbol?: string;
  quantity?: number;
  price?: number;
  taxFee: number;
  totalAmount: number;
  note?: string;
}

export interface PortfolioState {
  holdings: StockHolding[];
  transactions: Transaction[];
  cash: number;
}

export interface AIAnalysisResponse {
  summary: string;
  riskScore: number;
  recommendations: string[];
  sectorDistribution: { sector: string; value: number }[];
}
