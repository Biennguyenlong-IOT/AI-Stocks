
import { GoogleGenAI, Type } from "@google/genai";
import { StockHolding, AIAnalysisResponse } from "../types";

// Always use process.env.API_KEY directly in the named parameter.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzePortfolio = async (holdings: StockHolding[]): Promise<AIAnalysisResponse> => {
  // Use gemini-3-pro-preview for complex reasoning tasks like financial analysis.
  const model = "gemini-3-pro-preview";
  
  const prompt = `Hãy phân tích danh mục chứng khoán sau đây của tôi:
    ${holdings.map(h => `- Mã: ${h.symbol}, Tên: ${h.name}, Số lượng: ${h.quantity}, Giá vốn: ${h.avgPrice}, Giá hiện tại: ${h.currentPrice}, Nhóm ngành: ${h.sector}`).join('\n')}
    
    Vui lòng cung cấp:
    1. Một bản tóm tắt ngắn gọn về tình trạng danh mục.
    2. Điểm rủi ro (từ 1 đến 10).
    3. 3-5 lời khuyên cụ thể để tối ưu hóa.
    4. Phân bổ theo nhóm ngành.
  `;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            riskScore: { type: Type.NUMBER },
            recommendations: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            sectorDistribution: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  sector: { type: Type.STRING },
                  value: { type: Type.NUMBER }
                }
              }
            }
          },
          required: ["summary", "riskScore", "recommendations", "sectorDistribution"]
        }
      }
    });

    // Extract text from GenerateContentResponse using the .text property.
    const result = JSON.parse(response.text || "{}");
    return result as AIAnalysisResponse;
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw error;
  }
};
