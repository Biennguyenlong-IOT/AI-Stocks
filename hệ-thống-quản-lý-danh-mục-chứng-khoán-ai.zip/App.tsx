
import React, { useState, useEffect, useMemo } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  Plus, 
  Minus,
  BrainCircuit, 
  LayoutDashboard,
  Settings,
  CloudDownload,
  AlertCircle,
  Wallet,
  Banknote,
  Gift,
  X,
  Loader2,
  Copy,
  Check,
  Zap,
  Star,
  ChevronRight
} from 'lucide-react';
import { StockHolding, Transaction, PortfolioState, TransactionType, AIAnalysisResponse } from './types';
import { analyzePortfolio } from './services/geminiService';

const App: React.FC = () => {
  const [holdings, setHoldings] = useState<StockHolding[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [cash, setCash] = useState<number>(0);
  
  // Script URL Persistence
  const [scriptUrl, setScriptUrl] = useState<string>(localStorage.getItem('google_script_url') || '');
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSynced, setLastSynced] = useState<string | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [syncError, setSyncError] = useState<string | null>(null);
  const [isCopied, setIsCopied] = useState(false);

  // AI Analysis state - Inline display
  const [aiAnalysis, setAiAnalysis] = useState<AIAnalysisResponse | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  const [showBuyModal, setShowBuyModal] = useState(false);
  const [showSellModal, setShowSellModal] = useState(false);
  const [showCashModal, setShowCashModal] = useState(false);
  const [showDividendModal, setShowDividendModal] = useState(false);
  
  const [selectedStock, setSelectedStock] = useState<StockHolding | null>(null);
  const [cashActionForm, setCashActionForm] = useState({ amount: 0, type: 'DEPOSIT' as 'DEPOSIT' | 'WITHDRAW' });
  
  const [transactionForm, setTransactionForm] = useState({
    symbol: '',
    quantity: 0,
    price: 0,
    taxFeePercent: 0.15,
    type: 'BUY' as TransactionType
  });

  const [dividendForm, setDividendForm] = useState({
    type: 'DIVIDEND_CASH' as 'DIVIDEND_CASH' | 'DIVIDEND_STOCK',
    amountPerShare: 0,
    stockBonusRatio: 0
  });

  const GAS_CODE = `function doGet(e) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var dataSheet = ss.getSheetByName("APP_DATA");
  if (!dataSheet) return ContentService.createTextOutput(JSON.stringify({})).setMimeType(ContentService.MimeType.JSON);
  
  var values = dataSheet.getDataRange().getValues();
  var state = { cash: 0, holdings: [], transactions: [] };
  
  var section = "";
  for (var i = 0; i < values.length; i++) {
    var row = values[i];
    if (row[0] === "CASH_BALANCE") {
      state.cash = parseFloat(row[1]) || 0;
    } else if (row[0] === "--- HOLDINGS ---") {
      section = "HOLDINGS"; i++; continue;
    } else if (row[0] === "--- TRANSACTIONS ---") {
      section = "TRANSACTIONS"; i++; continue;
    }
    
    if (section === "HOLDINGS" && row[0] && row[0] !== "ID") {
      state.holdings.push({
        id: row[0].toString(),
        symbol: row[1],
        name: row[2],
        quantity: parseFloat(row[3]),
        avgPrice: parseFloat(row[4]),
        currentPrice: parseFloat(row[5]),
        sector: row[6]
      });
    } else if (section === "TRANSACTIONS" && row[0] && row[0] !== "ID") {
      state.transactions.push({
        id: row[0].toString(), date: row[1], type: row[2], symbol: row[3],
        quantity: parseFloat(row[4]), price: parseFloat(row[5]), taxFee: parseFloat(row[6]),
        totalAmount: parseFloat(row[7]), note: row[8]
      });
    }
  }
  return ContentService.createTextOutput(JSON.stringify(state)).setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var state = JSON.parse(e.postData.contents);
  var dataSheet = ss.getSheetByName("APP_DATA") || ss.insertSheet("APP_DATA");
  dataSheet.clear();
  dataSheet.getRange("A1").setValue("CASH_BALANCE");
  dataSheet.getRange("B1").setValue(state.cash);
  dataSheet.getRange("A3").setValue("--- HOLDINGS ---");
  var hHeaders = ["ID", "Mã CP", "Tên", "Số lượng", "Giá vốn", "Giá hiện tại", "Ngành"];
  dataSheet.getRange(4, 1, 1, hHeaders.length).setValues([hHeaders]);
  if (state.holdings && state.holdings.length > 0) {
    var hData = state.holdings.map(function(h) { return [h.id, h.symbol, h.name, h.quantity, h.avgPrice, h.currentPrice, h.sector]; });
    dataSheet.getRange(5, 1, hData.length, hHeaders.length).setValues(hData);
  }
  var tStartRow = (state.holdings ? state.holdings.length : 0) + 7;
  dataSheet.getRange(tStartRow, 1).setValue("--- TRANSACTIONS ---");
  var tHeaders = ["ID", "Ngày", "Loại", "Mã", "SL", "Giá", "Phí", "Tổng", "Ghi chú"];
  dataSheet.getRange(tStartRow + 1, 1, 1, tHeaders.length).setValues([tHeaders]);
  if (state.transactions && state.transactions.length > 0) {
    var tData = state.transactions.map(function(t) { return [t.id, t.date, t.type, t.symbol || "", t.quantity || 0, t.price || 0, t.taxFee, t.totalAmount, t.note || ""]; });
    dataSheet.getRange(tStartRow + 2, 1, tData.length, tHeaders.length).setValues(tData);
  }
  return ContentService.createTextOutput(JSON.stringify({status: "success"})).setMimeType(ContentService.MimeType.JSON);
}`;

  useEffect(() => {
    const local = localStorage.getItem('portfolio_full_state');
    if (local) {
      try {
        const saved = JSON.parse(local);
        setHoldings(saved.holdings || []);
        setTransactions(saved.transactions || []);
        setCash(saved.cash || 0);
      } catch (e) { console.error("Local data corrupt", e); }
    }
    if (scriptUrl) fetchFromSheets(true);
  }, []);

  const stats = useMemo(() => {
    const stockValue = holdings.reduce((acc, curr) => acc + (curr.quantity * (curr.currentPrice || 0)), 0);
    const totalAssets = cash + stockValue;
    const totalDeposited = transactions.filter(t => t.type === 'DEPOSIT').reduce((acc, curr) => acc + curr.totalAmount, 0);
    const totalWithdrawn = transactions.filter(t => t.type === 'WITHDRAW').reduce((acc, curr) => acc + curr.totalAmount, 0);
    const netCapital = totalDeposited - totalWithdrawn;
    const profit = totalAssets - netCapital;
    const profitPercent = netCapital > 0 ? (profit / netCapital) * 100 : 0;
    return { cash, stockValue, totalAssets, netCapital, profit, profitPercent };
  }, [holdings, transactions, cash]);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(GAS_CODE);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handleAnalyze = async () => {
    if (holdings.length === 0) return;
    setIsAnalyzing(true);
    setSyncError(null);
    try {
      const result = await analyzePortfolio(holdings);
      setAiAnalysis(result);
    } catch (error) {
      setSyncError("AI hiện tại không phản hồi.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const fetchFromSheets = async (silent = false) => {
    const url = scriptUrl.trim();
    if (!url || !url.includes('/exec')) return;
    if (!silent) setIsSyncing(true);
    try {
      const response = await fetch(`${url}?t=${Date.now()}`);
      if (!response.ok) throw new Error();
      const data = await response.json();
      if (data && (data.holdings || data.cash !== undefined)) {
        setHoldings(data.holdings || []);
        setTransactions(data.transactions || []);
        setCash(data.cash || 0);
        setLastSynced(new Date().toLocaleTimeString());
        localStorage.setItem('portfolio_full_state', JSON.stringify(data));
      }
    } catch (e) {
      if (!silent) setSyncError("Lỗi kết nối Cloud.");
    } finally {
      if (!silent) setIsSyncing(false);
    }
  };

  const pushToSheets = async (currentState: PortfolioState) => {
    const url = scriptUrl.trim();
    if (!url || !url.includes('/exec')) return;
    setIsSyncing(true);
    try {
      localStorage.setItem('portfolio_full_state', JSON.stringify(currentState));
      await fetch(url, { method: 'POST', mode: 'no-cors', body: JSON.stringify(currentState) });
      setLastSynced(new Date().toLocaleTimeString());
      setTimeout(() => fetchFromSheets(true), 3000);
    } catch (e) {
      setSyncError("Lỗi lưu dữ liệu.");
    } finally {
      setTimeout(() => setIsSyncing(false), 1000);
    }
  };

  const resetForms = () => {
    setTransactionForm({ symbol: '', quantity: 0, price: 0, taxFeePercent: 0.15, type: 'BUY' });
    setCashActionForm({ amount: 0, type: 'DEPOSIT' });
    setDividendForm({ type: 'DIVIDEND_CASH', amountPerShare: 0, stockBonusRatio: 0 });
  };

  const handleBuy = (e: React.FormEvent) => {
    e.preventDefault();
    const { symbol, quantity, price, taxFeePercent } = transactionForm;
    const totalCost = (quantity * price) * (1 + (taxFeePercent || 0) / 100);
    if (totalCost > cash) { alert("Tiền mặt không đủ!"); return; }
    
    const uppercaseSymbol = symbol.toUpperCase();
    let newHoldings = [...holdings];
    const idx = newHoldings.findIndex(h => h.symbol === uppercaseSymbol);
    if (idx > -1) {
      const h = newHoldings[idx];
      const newQty = h.quantity + quantity;
      const newAvg = ((h.quantity * h.avgPrice) + (quantity * price)) / newQty;
      newHoldings[idx] = { ...h, quantity: newQty, avgPrice: newAvg };
    } else {
      newHoldings.push({ id: Date.now().toString(), symbol: uppercaseSymbol, name: uppercaseSymbol, quantity, avgPrice: price, currentPrice: price, sector: 'Chưa rõ' });
    }
    
    const newCash = cash - totalCost;
    const newTransactions = [{ id: Date.now().toString(), date: new Date().toLocaleString('vi-VN'), type: 'BUY', symbol: uppercaseSymbol, quantity, price, taxFee: totalCost - (quantity * price), totalAmount: totalCost } as Transaction, ...transactions];
    
    setHoldings(newHoldings); setCash(newCash); setTransactions(newTransactions);
    setShowBuyModal(false); resetForms();
    pushToSheets({ holdings: newHoldings, transactions: newTransactions, cash: newCash });
  };

  const handleSell = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStock) return;
    const { quantity, price, taxFeePercent } = transactionForm;
    if (quantity > selectedStock.quantity) { alert("Không đủ khối lượng!"); return; }
    
    const totalReceive = (quantity * price) * (1 - (taxFeePercent || 0) / 100);
    const newHoldings = holdings.map(h => h.id === selectedStock.id ? { ...h, quantity: h.quantity - quantity } : h).filter(h => h.quantity > 0);
    const newCash = cash + totalReceive;
    const newTransactions = [{ id: Date.now().toString(), date: new Date().toLocaleString('vi-VN'), type: 'SELL', symbol: selectedStock.symbol, quantity, price, taxFee: (quantity * price) - totalReceive, totalAmount: totalReceive } as Transaction, ...transactions];
    
    setHoldings(newHoldings); setCash(newCash); setTransactions(newTransactions);
    setShowSellModal(false); resetForms();
    pushToSheets({ holdings: newHoldings, transactions: newTransactions, cash: newCash });
  };

  const handleCashAction = (e: React.FormEvent) => {
    e.preventDefault();
    const { amount, type } = cashActionForm;
    if (amount <= 0) return;
    const newCash = type === 'DEPOSIT' ? cash + amount : cash - amount;
    const newTransactions = [{ id: Date.now().toString(), date: new Date().toLocaleString('vi-VN'), type, taxFee: 0, totalAmount: amount, note: type === 'DEPOSIT' ? 'Nạp vốn' : 'Rút vốn' }, ...transactions];
    setCash(newCash); setTransactions(newTransactions); setShowCashModal(false); resetForms();
    pushToSheets({ holdings, transactions: newTransactions, cash: newCash });
  };

  const formatDisplayValue = (val: number) => {
    if (val < 1 && val > 0) return val.toString().replace('.', ',');
    return val.toLocaleString('vi-VN');
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-[#020617] text-[#f8fafc]">
      <aside className="w-full md:w-72 glass-panel border-r border-slate-800 flex flex-col shrink-0">
        <div className="p-8 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3 text-emerald-400">
            <div className="bg-emerald-500/20 p-2 rounded-xl"><TrendingUp size={24} /></div>
            <h1 className="font-black text-lg tracking-tight uppercase">AI Portfolio</h1>
          </div>
          {(isSyncing || isAnalyzing) && <Loader2 size={18} className="text-emerald-400 animate-spin" />}
        </div>
        
        <nav className="flex-1 p-6 space-y-2">
          <button className="flex items-center gap-3 w-full p-4 rounded-2xl bg-emerald-500/10 text-emerald-400 font-bold"><LayoutDashboard size={20} />Dashboard</button>
          <button onClick={() => setShowCashModal(true)} className="flex items-center gap-3 w-full p-4 rounded-2xl hover:bg-slate-800 text-slate-400 transition-all"><Banknote size={20} />Nạp/Rút Tiền</button>
          <button onClick={() => fetchFromSheets()} disabled={isSyncing} className="flex items-center gap-3 w-full p-4 rounded-2xl hover:bg-slate-800 text-slate-400 transition-all"><CloudDownload size={20} />Lấy Dữ Liệu</button>
          <button onClick={() => setShowSettings(true)} className="flex items-center gap-3 w-full p-4 rounded-2xl hover:bg-slate-800 text-slate-400 transition-all"><Settings size={20} />Cài Đặt Script</button>
        </nav>

        <div className="p-6 mt-auto border-t border-slate-800/50">
          <div className="text-[10px] text-slate-500 font-black uppercase tracking-widest mb-2">Sync: {lastSynced || "N/A"}</div>
          <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800">
            <div className="text-xs text-slate-500 font-bold mb-1">Tiền mặt</div>
            <p className="text-lg font-black text-white">{stats.cash.toLocaleString('vi-VN')} đ</p>
          </div>
        </div>
      </aside>

      <main className="flex-1 overflow-y-auto p-6 md:p-10 space-y-8">
        <header className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <h2 className="text-3xl font-black">Tổng Quan</h2>
          <button onClick={() => setShowBuyModal(true)} className="flex items-center gap-3 bg-white text-slate-950 px-8 py-4 rounded-2xl font-black hover:scale-105 transition-all"><Plus size={20} />MUA MỚI</button>
        </header>

        <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard label="Tài sản" value={stats.totalAssets.toLocaleString('vi-VN')} icon={<Wallet className="text-blue-400" size={24} />} />
          <StatCard label="Vốn nạp" value={stats.netCapital.toLocaleString('vi-VN')} icon={<Banknote className="text-amber-400" size={24} />} />
          <StatCard label="Tiền mặt" value={stats.cash.toLocaleString('vi-VN')} icon={<Wallet className="text-emerald-400" size={24} />} />
          <StatCard label="Lãi / Lỗ" value={stats.profit.toLocaleString('vi-VN')} trend={stats.profit >= 0 ? 'up' : 'down'} subValue={`${stats.profitPercent.toFixed(2)}%`} icon={stats.profit >= 0 ? <TrendingUp size={24} /> : <TrendingDown size={24} />} />
        </section>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
          <div className="xl:col-span-2">
            <div className="glass-panel rounded-[2rem] overflow-hidden border border-slate-800/50 shadow-2xl">
              <div className="p-8 border-b border-slate-800/50 flex justify-between bg-slate-900/30">
                <h3 className="font-black text-lg text-slate-200 uppercase tracking-tight">Danh mục nắm giữ</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-slate-900/50 text-slate-500 text-[10px] uppercase font-black tracking-widest">
                    <tr><th className="px-8 py-6">Mã CP</th><th className="px-8 py-6">SL</th><th className="px-8 py-6 text-right">Giá Vốn/Hiện Tại</th><th className="px-8 py-6 text-right">Biến Động</th><th className="px-8 py-6"></th></tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/40">
                    {holdings.map((stock) => {
                      const p = (stock.currentPrice - stock.avgPrice) * stock.quantity;
                      const pp = stock.avgPrice > 0 ? ((stock.currentPrice - stock.avgPrice) / stock.avgPrice) * 100 : 0;
                      return (
                        <tr key={stock.id} className="hover:bg-emerald-500/5 transition-colors group">
                          <td className="px-8 py-6 font-black text-emerald-400 text-xl">{stock.symbol}</td>
                          <td className="px-8 py-6 font-mono font-bold text-slate-300">{formatDisplayValue(stock.quantity)}</td>
                          <td className="px-8 py-6 text-right">
                            <div className="text-[10px] text-slate-500">{formatDisplayValue(stock.avgPrice)}</div>
                            <div className="font-bold">{formatDisplayValue(stock.currentPrice)}</div>
                          </td>
                          <td className={`px-8 py-6 text-right font-black ${p >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                            <div>{p >= 0 ? '+' : ''}{formatDisplayValue(p)}</div>
                            <div className="text-[10px]">{pp.toFixed(2)}%</div>
                          </td>
                          <td className="px-8 py-6 text-right space-x-2">
                            <button onClick={() => { setSelectedStock(stock); setShowSellModal(true); setTransactionForm(f => ({...f, symbol: stock.symbol})); }} className="p-2 bg-rose-500/10 text-rose-400 rounded-lg hover:bg-rose-500 hover:text-white transition-all"><Minus size={16} /></button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          
          <div className="space-y-6">
            <div className="glass-panel p-8 rounded-[2rem] border border-indigo-500/20 bg-indigo-500/5 relative overflow-hidden flex flex-col h-full min-h-[450px]">
              <div className="flex items-center gap-3 mb-8 relative z-10">
                <div className="bg-indigo-500/20 p-2 rounded-xl text-indigo-400"><BrainCircuit size={24} /></div>
                <h3 className="font-black text-white text-lg">AI Advisor</h3>
              </div>

              {!aiAnalysis ? (
                <div className="text-center py-10 relative z-10 my-auto">
                  <Zap className="text-indigo-400/20 mx-auto mb-4" size={60} />
                  <p className="text-sm text-slate-400 mb-8 px-4 leading-relaxed italic">"Dữ liệu danh mục sẽ được Gemini AI phân tích rủi ro và gợi ý chiến lược."</p>
                  <button onClick={handleAnalyze} disabled={holdings.length === 0 || isAnalyzing} className="w-full py-5 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-500 rounded-2xl font-black text-xs uppercase shadow-lg transition-all flex items-center justify-center gap-2 group">
                    {isAnalyzing ? <><Loader2 size={18} className="animate-spin" /> ĐANG PHÂN TÍCH...</> : <><Zap size={18} className="group-hover:animate-pulse" /> Phân tích ngay</>}
                  </button>
                </div>
              ) : (
                <div className="space-y-6 relative z-10 animate-in fade-in slide-in-from-bottom-4 duration-500 overflow-y-auto custom-scrollbar">
                  <div className="flex items-center justify-between p-5 bg-indigo-500/10 border border-indigo-500/20 rounded-2xl">
                    <div>
                      <div className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-1">Điểm rủi ro</div>
                      <div className="text-3xl font-black text-white">{aiAnalysis.riskScore}/10</div>
                    </div>
                    <div className={`text-[10px] font-bold px-3 py-1.5 rounded-lg ${aiAnalysis.riskScore > 7 ? 'bg-rose-500/20 text-rose-400' : aiAnalysis.riskScore > 4 ? 'bg-amber-500/20 text-amber-400' : 'bg-emerald-500/20 text-emerald-400'}`}>
                      {aiAnalysis.riskScore > 7 ? 'CAO' : aiAnalysis.riskScore > 4 ? 'VỪA' : 'THẤP'}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-black text-slate-300 flex items-center gap-2 uppercase text-[10px] tracking-wider"><Star className="text-amber-400" size={14}/> Tóm tắt</h4>
                    <p className="text-xs text-slate-400 leading-relaxed bg-slate-900/50 p-4 rounded-2xl border border-slate-800 italic">"{aiAnalysis.summary}"</p>
                  </div>
                  <div className="space-y-3">
                    <h4 className="font-black text-slate-300 flex items-center gap-2 uppercase text-[10px] tracking-wider"><Zap className="text-indigo-400" size={14}/> Lời khuyên</h4>
                    <div className="grid gap-2">
                      {aiAnalysis.recommendations.map((rec, i) => (
                        <div key={i} className="p-3 bg-slate-900/80 border border-slate-800 rounded-xl text-[11px] text-slate-400 leading-relaxed flex gap-2">
                          <ChevronRight size={14} className="text-indigo-500 shrink-0 mt-0.5" />
                          <span>{rec}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <button onClick={handleAnalyze} disabled={isAnalyzing} className="w-full py-4 bg-slate-800 hover:bg-slate-700 rounded-xl font-bold text-[10px] uppercase text-slate-400 border border-slate-700/50">LÀM MỚI</button>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      {showSettings && (
        <Modal title="Cấu hình Google Sheet" onClose={() => setShowSettings(false)} wide>
          <div className="space-y-6">
            <Input label="Web App URL" value={scriptUrl} onChange={setScriptUrl} placeholder="https://script.google.com/macros/s/.../exec" />
            <div className="space-y-3">
              <div className="flex justify-between items-center px-1">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Mã Script (Cập nhật code.gs)</label>
                <button onClick={copyToClipboard} className="text-[10px] text-emerald-400 font-bold flex items-center gap-1 hover:text-emerald-300 transition-colors">
                  {isCopied ? <Check size={12}/> : <Copy size={12}/>} {isCopied ? "ĐÃ COPY" : "SAO CHÉP MÃ"}
                </button>
              </div>
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 overflow-hidden">
                <pre className="text-[10px] text-slate-400 font-mono h-40 overflow-y-auto leading-relaxed custom-scrollbar italic">{GAS_CODE}</pre>
              </div>
            </div>
            <button onClick={() => { localStorage.setItem('google_script_url', scriptUrl); setShowSettings(false); fetchFromSheets(); }} className="w-full bg-indigo-600 py-5 rounded-2xl font-black uppercase text-sm shadow-xl hover:bg-indigo-500 transition-all">LƯU CẤU HÌNH & KẾT NỐI</button>
          </div>
        </Modal>
      )}

      {showBuyModal && (
        <Modal title="Lệnh Mua Cổ Phiếu" onClose={() => { setShowBuyModal(false); resetForms(); }}>
          <form onSubmit={handleBuy} className="space-y-4">
            <Input label="Mã CP" value={transactionForm.symbol} onChange={v => setTransactionForm({...transactionForm, symbol: v})} placeholder="VND, HPG..." required uppercase />
            <div className="grid grid-cols-2 gap-4">
              <Input label="Số lượng" type="decimal" value={transactionForm.quantity} onChange={v => setTransactionForm({...transactionForm, quantity: parseFloat(v) || 0})} required />
              <Input label="Giá mua" type="decimal" value={transactionForm.price} onChange={v => setTransactionForm({...transactionForm, price: parseFloat(v) || 0})} required />
            </div>
            <Input label="Phí (%)" type="decimal" value={transactionForm.taxFeePercent} onChange={v => setTransactionForm({...transactionForm, taxFeePercent: parseFloat(v) || 0})} />
            <button type="submit" className="w-full bg-emerald-600 py-5 rounded-2xl font-black uppercase text-sm shadow-lg hover:bg-emerald-500 transition-all">XÁC NHẬN MUA</button>
          </form>
        </Modal>
      )}

      {showSellModal && selectedStock && (
        <Modal title={`Bán: ${selectedStock.symbol}`} onClose={() => { setShowSellModal(false); resetForms(); }}>
          <form onSubmit={handleSell} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Input label="Số lượng bán" type="decimal" value={transactionForm.quantity} onChange={v => setTransactionForm({...transactionForm, quantity: parseFloat(v) || 0})} required />
              <Input label="Giá bán" type="decimal" value={transactionForm.price} onChange={v => setTransactionForm({...transactionForm, price: parseFloat(v) || 0})} required />
            </div>
            <Input label="Thuế & Phí (%)" type="decimal" value={transactionForm.taxFeePercent} onChange={v => setTransactionForm({...transactionForm, taxFeePercent: parseFloat(v) || 0})} />
            <button type="submit" className="w-full bg-rose-600 py-5 rounded-2xl font-black uppercase text-sm shadow-lg hover:bg-rose-500 transition-all">XÁC NHẬN BÁN</button>
          </form>
        </Modal>
      )}

      {showCashModal && (
        <Modal title="Quản lý Vốn" onClose={() => { setShowCashModal(false); resetForms(); }}>
          <form onSubmit={handleCashAction} className="space-y-6">
            <div className="grid grid-cols-2 gap-4 p-1 bg-slate-950 rounded-2xl border border-slate-800">
              <button type="button" onClick={() => setCashActionForm({...cashActionForm, type: 'DEPOSIT'})} className={`py-3 rounded-xl text-[10px] font-black uppercase transition-all ${cashActionForm.type === 'DEPOSIT' ? 'bg-emerald-600 text-white' : 'text-slate-500'}`}>Nạp Vốn</button>
              <button type="button" onClick={() => setCashActionForm({...cashActionForm, type: 'WITHDRAW'})} className={`py-3 rounded-xl text-[10px] font-black uppercase transition-all ${cashActionForm.type === 'WITHDRAW' ? 'bg-rose-600 text-white' : 'text-slate-500'}`}>Rút Vốn</button>
            </div>
            <Input label="Số tiền VNĐ" isCurrency value={cashActionForm.amount} onChange={v => setCashActionForm({...cashActionForm, amount: parseFloat(v) || 0})} required />
            <button type="submit" className={`w-full py-5 rounded-2xl font-black uppercase text-sm ${cashActionForm.type === 'DEPOSIT' ? 'bg-emerald-600 hover:bg-emerald-500' : 'bg-rose-600 hover:bg-rose-500'} transition-all shadow-xl`}>GIAO DỊCH</button>
          </form>
        </Modal>
      )}
    </div>
  );
};

const StatCard: React.FC<{ label: string; value: string; icon: React.ReactNode; trend?: 'up' | 'down'; subValue?: string }> = ({ label, value, icon, trend, subValue }) => (
  <div className="glass-panel p-6 rounded-3xl border border-slate-800 flex flex-col gap-3 group hover:border-emerald-500/30 transition-all">
    <div className="flex justify-between items-center"><span className="text-slate-500 text-[10px] font-black uppercase tracking-widest">{label}</span><div className="p-2 bg-slate-900 rounded-xl">{icon}</div></div>
    <div><div className={`text-xl font-black ${trend === 'up' ? 'text-emerald-400' : trend === 'down' ? 'text-rose-400' : 'text-slate-100'}`}>{value} đ</div>{subValue && <div className={`text-[10px] font-bold ${trend === 'up' ? 'text-emerald-500' : 'text-rose-500'}`}>{subValue}</div>}</div>
  </div>
);

const Modal: React.FC<{ title: string; children: React.ReactNode; onClose: () => void; wide?: boolean }> = ({ title, children, onClose, wide }) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-300">
    <div className={`glass-panel rounded-[2rem] w-full ${wide ? 'max-w-3xl' : 'max-w-lg'} p-8 border border-white/5 relative shadow-2xl animate-in zoom-in-95 duration-300`}>
      <button onClick={onClose} className="absolute top-6 right-6 text-slate-500 hover:text-white transition-colors"><X size={20} /></button>
      <h3 className="text-xl font-black mb-6 uppercase text-white tracking-tight">{title}</h3>
      {children}
    </div>
  </div>
);

const Input: React.FC<{ 
  label: string; value: string | number; onChange: (v: string) => void; 
  type?: string; placeholder?: string; required?: boolean; 
  uppercase?: boolean; isCurrency?: boolean;
}> = ({ label, value, onChange, type = 'text', placeholder, required, uppercase, isCurrency }) => {
  const displayValue = (val: string | number) => {
    if (val === 0 || val === "0") return "";
    return val.toString().replace('.', ',');
  };

  const isNumeric = isCurrency || type === 'decimal';

  return (
    <div className="space-y-2">
      <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-1">{label}</label>
      <input 
        type="text" 
        required={required}
        value={isCurrency ? (value ? parseFloat(value.toString()).toLocaleString('vi-VN') : '') : (isNumeric ? displayValue(value) : value)} 
        onChange={e => {
          let val = e.target.value;
          if (isNumeric) {
            // Numeric filtering: only numbers, dots, dashes, and commas
            val = val.replace(/[^0-9,.-]/g, '').replace(',', '.');
          }
          if (uppercase) val = val.toUpperCase();
          onChange(val);
        }}
        placeholder={placeholder}
        className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-6 py-4 text-sm font-bold focus:ring-2 focus:ring-indigo-500 outline-none text-white transition-all shadow-inner"
      />
    </div>
  );
};

export default App;
